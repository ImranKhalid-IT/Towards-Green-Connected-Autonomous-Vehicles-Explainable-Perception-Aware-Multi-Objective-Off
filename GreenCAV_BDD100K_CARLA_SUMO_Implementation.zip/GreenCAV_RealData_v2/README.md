# GreenCAV: BDD100K + CARLA/SUMO real-data implementation

This is a modular implementation scaffold for the selected strategy:
**BDD100K real-world benchmark + CARLA 0.9.15 / SUMO 1.19 controlled
co-simulation + cloud NVIDIA GPU training**.

## Scientific protocol (read before running)

1. BDD100K official training labels are split deterministically into a
   training set and an internal validation set.
2. BDD100K official labelled validation is held out as the final benchmark.
   It must not be used for repeated hyperparameter tuning.
3. The official BDD100K test images must not be used for mAP unless labels
   are available to the research team under the dataset terms.
4. CARLA outputs are a separate synthetic-domain dataset. Do not merge its
   AP with BDD100K AP into one number. Report domain-specific results.
5. The CARLA collector currently labels a subset of categories. It is not a
   full 10-class BDD100K replacement. Validate every projected box visually.
6. The SUMO launcher delegates to CARLA's official `run_synchronization.py`.
   It does not implement a homemade actor mirror.
7. Cloud GPU training measures cloud inference, not vehicle-side Jetson
   energy. Use target onboard/MEC hardware or calibrated power instrumentation
   for system energy claims.
8. No target result (including 83.1% mAP) is hard-coded. Report measured values.

## Cloud GPU setup

Use an Ubuntu cloud VM with NVIDIA GPU. 24 GB VRAM is comfortable for 640px
training; lower VRAM requires smaller batches. Record GPU model, VRAM, driver,
CUDA, PyTorch, Ultralytics versions and VM type.

```bash
python -m venv .venv
source .venv/bin/activate
pip install --upgrade pip
pip install -e ".[all]"
python -m greencav.provenance
```

For strict reproducibility, pin exact package versions after the pilot run and
save `pip freeze > outputs/requirements-lock.txt`.

## BDD100K download and folder structure

Download the official **100K Images** and **Detection 2020 Labels** from
https://www.vis.xyz/bdd100k/ or https://doc.bdd100k.com/download.html.
Follow the dataset's access and licence terms. This package does not bypass
the official download process.

Expected layout:

```text
data/bdd100k/
  images/100k/train/*.jpg
  images/100k/val/*.jpg
  images/100k/test/*.jpg
  labels/bdd100k_labels_images_train.json
  labels/bdd100k_labels_images_val.json
```

Then convert labels and create the internal validation split:

```bash
python scripts/prepare_bdd100k.py
```

The generated `data/bdd100k_yolo/split_manifest.json` records split counts.
Inspect labels by overlaying boxes on at least 100 random images and verify
class IDs before any long training run.

## Detector training

### YOLOv8s / YOLOv8m

```bash
python scripts/train_yolo.py --model yolov8s --epochs 100 --batch 16 --device 0
python scripts/train_yolo.py --model yolov8m --epochs 100 --batch 8 --device 0
```

### Exact YOLOv5s

The shell script clones the official YOLOv5 repository and runs `yolov5s.pt`.
Record the displayed Git commit and pin it in your experiment log.

```bash
bash scripts/train_yolov5s.sh
```

Do not call `yolov5su.pt` the original YOLOv5s; it is a different Ultralytics
YOLOv5u checkpoint family.

### Faster R-CNN

```bash
python scripts/train_fasterrcnn.py --epochs 20 --batch 4 --device cuda
python scripts/evaluate_fasterrcnn.py --checkpoint checkpoints/fasterrcnn_bdd100k.pth
```

The Faster R-CNN evaluator uses COCO-style AP at IoU thresholds 0.50:0.95 and
reports AP50. Validate the evaluator on a small manually inspected subset.

## Final BDD100K benchmark evaluation

Only after model selection is complete, evaluate on the official labelled
validation partition:

```bash
python scripts/evaluate_yolo.py --weights runs/bdd100k/yolov8s/weights/best.pt
python scripts/evaluate_yolo.py --weights runs/bdd100k/yolov8m/weights/best.pt
```

YOLOv5 evaluation should use the same pinned official YOLOv5 repository and
its validation command with `--task val`. Keep the evaluation settings,
image size, confidence/NMS settings and class taxonomy consistent.

## Weather-stratified BDD100K evaluation

```bash
python scripts/export_weather.py \
  --labels data/bdd100k/labels/bdd100k_labels_images_val.json \
  --images data/bdd100k/images/100k/val
```

This exports manifests and sample counts. To report AP by weather, run each
detector on each manifest and match predictions against the corresponding
ground truth using one fixed evaluator. Report sample counts for every group.

## Latency and hardware profiling

```bash
python scripts/profile_detector.py \
  --weights runs/bdd100k/yolov8s/weights/best.pt \
  --source "data/bdd100k_yolo/images/benchmark/*.jpg" --device 0 --repeats 300
```

This is model-only inference latency on the cloud GPU. It is not end-to-end
vehicle-to-edge latency. For energy, use NVML power sampling or a calibrated
external meter on the actual target device. Do not substitute cloud GPU
energy for onboard or MEC energy.

## CARLA 0.9.15 collection

Start CARLA server and run:

```bash
python -m greencav.carla_collect --frames 1000 --weather clear --out data/carla/clear
python -m greencav.carla_collect --frames 1000 --weather rain --out data/carla/rain
python -m greencav.carla_collect --frames 1000 --weather fog --out data/carla/fog
```

The collector saves camera frames and projected boxes for supported actor
types. Projection must be checked visually and against CARLA's official
camera/bounding-box examples before using as ground truth. Current class
coverage is a subset of BDD100K (not all ten categories).

## CARLA + SUMO official synchronization

Install SUMO 1.19 and use the CARLA 0.9.15 distribution's official bridge:
`PythonAPI/examples/sumo_integration/run_synchronization.py`.

```bash
python scripts/run_official_sumo_bridge.py \
  --bridge-script /path/to/CARLA_0.9.15/PythonAPI/examples/sumo_integration/run_synchronization.py \
  --bridge-args "--help"
```

After reviewing the official script's help for your exact release, pass its
documented SUMO config and synchronization options through `--bridge-args`.
Save SUMO network, route, config, bridge logs, CARLA map and random seeds.

## Empirical profiles for GreenCAV PPO

After evaluating and profiling all detectors:

```bash
python scripts/build_empirical_profiles.py
python scripts/merge_results.py
```

`empirical_detector_profiles.json` contains measured mAP and latency where
available. Energy is intentionally null unless separately measured on the
target vehicle/edge hardware. Integrate these profiles into the PPO observation
and reward configuration. Ground-truth labels must not be available to the
runtime policy; they are used only for offline evaluation/training labels.

## Suggested execution order

1. Cloud GPU environment + provenance.
2. Download BDD100K and convert annotations.
3. Inspect converted labels and split manifest.
4. Pilot train YOLOv8s and Faster R-CNN (small epochs/subset).
5. Full training of YOLOv5s, YOLOv8s, YOLOv8m and Faster R-CNN.
6. Final official-validation evaluation.
7. Weather-stratified evaluation.
8. Inference latency profiling; target hardware energy measurement.
9. CARLA scenario generation and annotation validation.
10. Run CARLA's official SUMO integration bridge.
11. Feed empirical detector profiles into PPO/XAI.
12. Run 30 independent end-to-end seeds and archive raw logs.

## Files

- `greencav/bdd_converter.py`: annotation conversion and split policy.
- `greencav/yolo_train.py`: YOLOv8 training and evaluation.
- `greencav/fasterrcnn.py`: Faster R-CNN dataset, training and AP evaluation.
- `greencav/profile.py`: GPU inference latency.
- `greencav/weather.py`: weather metadata manifests.
- `greencav/carla_collect.py`: CARLA RGB and projected boxes.
- `greencav/official_bridge.py`: launcher for official CARLA-SUMO bridge.
- `greencav/empirical_profiles.py`: measured detector profile export.
- `greencav/provenance.py`: software and GPU environment capture.

## Limitations to resolve before Q1 submission

- Verify the BDD100K label archive schema and manually audit converted boxes.
- Complete and validate per-weather AP evaluation with the official labels.
- Validate CARLA box projection, occlusion handling and supported class taxonomy.
- Use the official CARLA-SUMO bridge with actor-level synchronization.
- Implement actual target hardware energy measurement.
- Run all four detectors with documented settings and evaluate them with
  consistent metrics. Faster R-CNN and YOLO evaluator parity must be verified.
- Do not claim numerical reproduction until the full experiments have run.
