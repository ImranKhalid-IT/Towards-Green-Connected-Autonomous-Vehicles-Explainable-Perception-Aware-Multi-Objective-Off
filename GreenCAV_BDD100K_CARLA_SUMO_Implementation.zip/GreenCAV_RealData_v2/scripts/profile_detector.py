import argparse,json
from greencav.profile import profile
p=argparse.ArgumentParser(); p.add_argument("--weights",required=True)
p.add_argument("--source",default="data/bdd100k_yolo/images/benchmark/*.jpg")
p.add_argument("--device",default="0"); p.add_argument("--repeats",type=int,default=300)
a=p.parse_args(); print(json.dumps(profile(a.weights,a.source,repeats=a.repeats,device=a.device),indent=2))
