import argparse,json
from greencav.weather import export_weather_manifests
p=argparse.ArgumentParser(); p.add_argument("--labels",required=True); p.add_argument("--images",required=True)
a=p.parse_args(); print(json.dumps(export_weather_manifests(a.labels,a.images),indent=2))
