import json
from greencav.bdd_converter import convert_bdd100k
print(json.dumps(convert_bdd100k(),indent=2))
