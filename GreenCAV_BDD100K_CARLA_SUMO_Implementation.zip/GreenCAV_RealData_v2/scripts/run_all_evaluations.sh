#!/usr/bin/env bash
set -euo pipefail
DEVICE="${DEVICE:-0}"
python scripts/evaluate_yolo.py --weights runs/bdd100k/yolov8s/weights/best.pt --device "$DEVICE"
python scripts/evaluate_yolo.py --weights runs/bdd100k/yolov8m/weights/best.pt --device "$DEVICE"
python scripts/evaluate_fasterrcnn.py --checkpoint checkpoints/fasterrcnn_bdd100k.pth --device cuda
# YOLOv5 official validation: execute from external/yolov5 with the same
# benchmark split and a runtime YAML whose path points at data/bdd100k_yolo.
