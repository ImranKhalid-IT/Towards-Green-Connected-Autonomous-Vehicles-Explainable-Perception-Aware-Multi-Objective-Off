import argparse,json
from pathlib import Path
from greencav.fasterrcnn import evaluate_fasterrcnn
p=argparse.ArgumentParser(); p.add_argument("--checkpoint",default="checkpoints/fasterrcnn_bdd100k.pth")
p.add_argument("--device",default="cuda")
a=p.parse_args(); r=evaluate_fasterrcnn("data/bdd100k_yolo",a.checkpoint,device=a.device)
Path("outputs").mkdir(exist_ok=True)
print(json.dumps(r,indent=2))
