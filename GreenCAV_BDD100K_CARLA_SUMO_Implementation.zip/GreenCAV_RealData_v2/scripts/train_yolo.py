import argparse
from greencav.yolo_train import train_yolo
p=argparse.ArgumentParser()
p.add_argument("--model",choices=["yolov8s","yolov8m"],required=True)
p.add_argument("--epochs",type=int,default=100); p.add_argument("--batch",type=int,default=16)
p.add_argument("--device",default="0")
a=p.parse_args(); train_yolo(a.model,epochs=a.epochs,batch=a.batch,device=a.device)
