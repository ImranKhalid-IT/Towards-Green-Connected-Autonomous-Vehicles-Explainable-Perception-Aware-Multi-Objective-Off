from greencav.results import merge
print(merge())
