from greencav.carla_collect import main
main()
