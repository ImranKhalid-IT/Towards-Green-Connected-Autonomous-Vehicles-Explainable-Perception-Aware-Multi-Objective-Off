import argparse,json
from pathlib import Path
from greencav.yolo_train import evaluate_yolo
p=argparse.ArgumentParser()
p.add_argument("--weights",required=True); p.add_argument("--device",default="0")
a=p.parse_args(); result=evaluate_yolo(a.weights,device=a.device)
Path("outputs").mkdir(exist_ok=True)
Path("outputs/eval_"+Path(a.weights).stem+".json").write_text(json.dumps(result,indent=2))
print(json.dumps(result,indent=2))
