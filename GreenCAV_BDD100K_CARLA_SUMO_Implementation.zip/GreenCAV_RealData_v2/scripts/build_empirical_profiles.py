import json
from greencav.empirical_profiles import build
print(json.dumps(build(),indent=2))
