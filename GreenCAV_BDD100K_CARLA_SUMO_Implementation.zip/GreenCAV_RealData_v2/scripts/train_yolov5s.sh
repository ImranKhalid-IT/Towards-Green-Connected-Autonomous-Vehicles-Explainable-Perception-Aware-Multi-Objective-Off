#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
if [ ! -d "$ROOT/external/yolov5" ]; then
  mkdir -p "$ROOT/external"
  git clone https://github.com/ultralytics/yolov5 "$ROOT/external/yolov5"
fi
DATA_YAML="$ROOT/configs/bdd100k_yolov5_runtime.yaml"
cat > "$DATA_YAML" <<EOF
path: $ROOT/data/bdd100k_yolo
train: images/train
val: images/val_internal
nc: 10
names: [pedestrian, rider, car, truck, bus, train, motorcycle, bicycle, traffic_light, traffic_sign]
EOF
cd "$ROOT/external/yolov5"
echo "YOLOv5 repository commit: $(git rev-parse HEAD)"
python -m pip install -r requirements.txt
python train.py --img 640 --batch "${BATCH:-16}" --epochs "${EPOCHS:-100}" \
  --data "$DATA_YAML" --weights yolov5s.pt \
  --project "$ROOT/runs/bdd100k" --name yolov5s --seed 42
