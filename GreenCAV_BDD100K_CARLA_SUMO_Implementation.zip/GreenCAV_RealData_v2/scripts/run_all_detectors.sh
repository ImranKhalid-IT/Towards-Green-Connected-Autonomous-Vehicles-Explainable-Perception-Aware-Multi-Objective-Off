#!/usr/bin/env bash
# Run after BDD100K has been downloaded and converted.
# Adjust BATCH according to cloud GPU VRAM.
set -euo pipefail
EPOCHS="${EPOCHS:-100}"
DEVICE="${DEVICE:-0}"
BATCH_SMALL="${BATCH_SMALL:-16}"
BATCH_MEDIUM="${BATCH_MEDIUM:-8}"

python scripts/train_yolo.py --model yolov8s --epochs "$EPOCHS" --batch "$BATCH_SMALL" --device "$DEVICE"
python scripts/train_yolo.py --model yolov8m --epochs "$EPOCHS" --batch "$BATCH_MEDIUM" --device "$DEVICE"
# Exact legacy YOLOv5s through official YOLOv5 repository.
BATCH="$BATCH_SMALL" EPOCHS="$EPOCHS" bash scripts/train_yolov5s.sh
# Faster R-CNN uses torchvision; adjust batch for VRAM.
python scripts/train_fasterrcnn.py --epochs 20 --batch 4 --device cuda
