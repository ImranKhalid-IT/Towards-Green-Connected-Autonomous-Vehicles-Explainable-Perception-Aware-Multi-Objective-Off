import argparse
from greencav.fasterrcnn import train_fasterrcnn
p=argparse.ArgumentParser(); p.add_argument("--epochs",type=int,default=20)
p.add_argument("--batch",type=int,default=4); p.add_argument("--device",default="cuda")
a=p.parse_args(); train_fasterrcnn(epochs=a.epochs,batch_size=a.batch,device=a.device)
