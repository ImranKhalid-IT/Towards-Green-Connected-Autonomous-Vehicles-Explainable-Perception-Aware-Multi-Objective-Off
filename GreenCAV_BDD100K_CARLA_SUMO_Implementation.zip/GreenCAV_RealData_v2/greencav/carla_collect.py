"""CARLA 0.9.15 RGB collection with projected 2D boxes for supported actors.

Labels currently supported: pedestrian, car, truck, bus, motorcycle, bicycle,
traffic_light, traffic_sign. This is NOT the complete BDD100K taxonomy.
Projection must be visually validated before using these annotations as
scientific ground truth. Camera calibration and occlusion truncation are saved.
"""
import argparse, json, random, queue
from pathlib import Path
import numpy as np
try: import carla
except ImportError as e: raise SystemExit("CARLA 0.9.15 PythonAPI not importable.") from e

def actor_class(actor):
    t=actor.type_id.lower()
    if t.startswith("walker."): return "pedestrian"
    if t.startswith("traffic.traffic_light"): return "traffic_light"
    if t.startswith("traffic."): return "traffic_sign"
    if t.startswith("vehicle."):
        if any(x in t for x in ["truck","carlacola","firetruck"]): return "truck"
        if "bus" in t: return "bus"
        if any(x in t for x in ["motorcycle","yamaha","harley"]): return "motorcycle"
        if "bicycle" in t: return "bicycle"
        return "car"
    return None

def project_bbox(actor,camera,width,height,fov):
    inv=np.array(camera.get_transform().get_inverse_matrix())
    verts=actor.bounding_box.get_world_vertices(actor.get_transform())
    fx=width/(2*np.tan(np.deg2rad(fov)/2)); cx=width/2; cy=height/2
    pts=[]
    for v in verts:
        q=np.array([v.x,v.y,v.z,1.0]); c=inv@q
        # CARLA camera coordinates: x forward, y right, z up.
        depth, right, up = c[0], c[1], c[2]
        if depth > 0.1:
            pts.append((cx+fx*right/depth, cy-fx*up/depth))
    if len(pts)<4: return None
    x1=max(0,min(p[0] for p in pts)); y1=max(0,min(p[1] for p in pts))
    x2=min(width,max(p[0] for p in pts)); y2=min(height,max(p[1] for p in pts))
    if x2-x1<2 or y2-y1<2: return None
    return [float(x1),float(y1),float(x2),float(y2)]

def main():
    p=argparse.ArgumentParser()
    p.add_argument("--host",default="127.0.0.1"); p.add_argument("--port",type=int,default=2000)
    p.add_argument("--frames",type=int,default=1000); p.add_argument("--out",required=True)
    p.add_argument("--weather",choices=["clear","rain","fog"],default="clear")
    p.add_argument("--vehicles",type=int,default=20); p.add_argument("--seed",type=int,default=42)
    a=p.parse_args(); random.seed(a.seed)
    out=Path(a.out); (out/"images").mkdir(parents=True,exist_ok=True)
    client=carla.Client(a.host,a.port); client.set_timeout(30); world=client.get_world()
    old=world.get_settings(); settings=world.get_settings()
    settings.synchronous_mode=True; settings.fixed_delta_seconds=0.1
    world.apply_settings(settings)
    weather={"clear":carla.WeatherParameters.ClearNoon,
             "rain":carla.WeatherParameters.HardRainNoon,
             "fog":carla.WeatherParameters.FoggyNoon}[a.weather]
    world.set_weather(weather)
    actors=[]; sensor=None; rows=[]; q=queue.Queue()
    try:
        spawn=world.get_map().get_spawn_points()
        if not spawn: raise RuntimeError("No spawn points in current CARLA map.")
        random.shuffle(spawn); ego=world.try_spawn_actor(
            world.get_blueprint_library().find("vehicle.tesla.model3"),spawn[0])
        if ego is None: raise RuntimeError("Unable to spawn ego vehicle.")
        actors.append(ego); ego.set_autopilot(True)
        tm=client.get_trafficmanager(); tm.set_synchronous_mode(True)
        bps=world.get_blueprint_library().filter("vehicle.*")
        spawned=0
        for tr in spawn[1:]:
            if spawned>=a.vehicles: break
            actor=world.try_spawn_actor(random.choice(bps),tr)
            if actor:
                actors.append(actor); actor.set_autopilot(True); spawned+=1
        cam_bp=world.get_blueprint_library().find("sensor.camera.rgb")
        width,height,fov=1280,720,90
        cam_bp.set_attribute("image_size_x",str(width)); cam_bp.set_attribute("image_size_y",str(height))
        cam_bp.set_attribute("fov",str(fov))
        sensor=world.spawn_actor(cam_bp,carla.Transform(carla.Location(x=1.5,z=2.4)),attach_to=ego)
        sensor.listen(q.put)
        for idx in range(a.frames):
            world.tick()
            image=q.get(timeout=5)
            name=f"{idx:08d}.jpg"; image.save_to_disk(str(out/"images"/name))
            labels=[]
            for actor in world.get_actors():
                if actor.id==ego.id: continue
                category=actor_class(actor)
                if category is None: continue
                box=project_bbox(actor,sensor,width,height,fov)
                if box:
                    labels.append({"category":category,"bbox_xyxy":box,"actor_id":actor.id,
                                   "type_id":actor.type_id})
            rows.append({"file_name":name,"width":width,"height":height,
                         "weather":a.weather,"frame":idx,"labels":labels})
    finally:
        if sensor:
            sensor.stop(); sensor.destroy()
        for actor in actors:
            if actor.is_alive: actor.destroy()
        try: client.get_trafficmanager().set_synchronous_mode(False)
        except Exception: pass
        world.apply_settings(old)
    (out/"annotations.jsonl").write_text("\n".join(json.dumps(x) for x in rows)+"\n")
    (out/"metadata.json").write_text(json.dumps({"carla_version":client.get_server_version(),
        "map":world.get_map().name,"weather":a.weather,"frames":len(rows),
        "supported_labels":["pedestrian","car","truck","bus","motorcycle","bicycle","traffic_light","traffic_sign"],
        "seed":a.seed},indent=2))
    print(f"Collected {len(rows)} frames: {out}")

if __name__=="__main__": main()
