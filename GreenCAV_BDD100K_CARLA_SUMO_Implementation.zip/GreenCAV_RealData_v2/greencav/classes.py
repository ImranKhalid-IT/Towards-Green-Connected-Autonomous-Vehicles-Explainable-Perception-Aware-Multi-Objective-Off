BDD_CLASSES = [
    "pedestrian", "rider", "car", "truck", "bus",
    "train", "motorcycle", "bicycle", "traffic_light", "traffic_sign"
]
CATEGORY_TO_ID = {
    "pedestrian": 0, "rider": 1, "car": 2, "truck": 3, "bus": 4,
    "train": 5, "motorcycle": 6, "bicycle": 7,
    "traffic light": 8, "traffic_light": 8,
    "traffic sign": 9, "traffic_sign": 9,
}
