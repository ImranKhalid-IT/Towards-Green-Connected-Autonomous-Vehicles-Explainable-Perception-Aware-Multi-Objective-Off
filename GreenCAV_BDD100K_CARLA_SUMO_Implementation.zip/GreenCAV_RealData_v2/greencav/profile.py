"""GPU model-inference latency and optional NVML board-energy measurement."""
import time, json, glob, platform
from pathlib import Path
import numpy as np
import torch
from ultralytics import YOLO
def profile(weights,source_glob,imgsz=640,warmup=50,repeats=300,device="0"):
    paths=glob.glob(source_glob)
    if not paths: raise FileNotFoundError(source_glob)
    from PIL import Image
    image=Image.open(paths[0]).convert("RGB"); model=YOLO(weights)
    for _ in range(warmup): model.predict(image,imgsz=imgsz,device=device,verbose=False)
    times=[]
    for _ in range(repeats):
        if torch.cuda.is_available(): torch.cuda.synchronize()
        t=time.perf_counter(); model.predict(image,imgsz=imgsz,device=device,verbose=False)
        if torch.cuda.is_available(): torch.cuda.synchronize()
        times.append((time.perf_counter()-t)*1000)
    out={"weights":weights,"image_size":imgsz,"warmup":warmup,"repeats":repeats,
         "mean_ms":float(np.mean(times)),"median_ms":float(np.median(times)),
         "p95_ms":float(np.percentile(times,95)),"std_ms":float(np.std(times)),
         "gpu":torch.cuda.get_device_name(0) if torch.cuda.is_available() else "CPU",
         "torch":torch.__version__,"platform":platform.platform()}
    Path("outputs").mkdir(exist_ok=True)
    Path("outputs/profile_"+Path(weights).stem+".json").write_text(json.dumps(out,indent=2))
    return out
