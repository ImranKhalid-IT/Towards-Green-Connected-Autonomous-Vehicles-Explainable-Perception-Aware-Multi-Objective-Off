"""Faster R-CNN ResNet50-FPN training and COCO-style evaluation."""
from pathlib import Path
import json, torch
from torch.utils.data import Dataset, DataLoader
from PIL import Image
from torchvision.models.detection import fasterrcnn_resnet50_fpn
from torchvision.models.detection.faster_rcnn import FastRCNNPredictor
from torchvision.transforms.functional import to_tensor
from pycocotools.coco import COCO
from pycocotools.cocoeval import COCOeval

class BDDYoloDataset(Dataset):
    def __init__(self, root, split):
        self.root=Path(root)
        self.images=sorted([p for p in (self.root/"images"/split).glob("*")
                            if p.suffix.lower() in {".jpg",".jpeg",".png"}])
        self.labels=self.root/"labels"/split
    def __len__(self): return len(self.images)
    def __getitem__(self,i):
        p=self.images[i]; im=Image.open(p).convert("RGB"); w,h=im.size
        boxes=[]; labels=[]
        f=self.labels/(p.stem+".txt")
        if f.exists():
            for line in f.read_text().splitlines():
                if not line.strip(): continue
                c,xc,yc,bw,bh=map(float,line.split())
                x1=(xc-bw/2)*w; y1=(yc-bh/2)*h
                x2=(xc+bw/2)*w; y2=(yc+bh/2)*h
                if x2>x1 and y2>y1: boxes.append([x1,y1,x2,y2]); labels.append(int(c)+1)
        target={"boxes":torch.tensor(boxes,dtype=torch.float32).reshape(-1,4),
                "labels":torch.tensor(labels,dtype=torch.int64),
                "image_id":torch.tensor([i]),
                "area":torch.tensor([(b[2]-b[0])*(b[3]-b[1]) for b in boxes],dtype=torch.float32),
                "iscrowd":torch.zeros((len(boxes),),dtype=torch.int64)}
        return to_tensor(im),target
def collate_fn(batch): return tuple(zip(*batch))
def build_model(pretrained=True):
    model=fasterrcnn_resnet50_fpn(weights="DEFAULT" if pretrained else None)
    in_features=model.roi_heads.box_predictor.cls_score.in_features
    model.roi_heads.box_predictor=FastRCNNPredictor(in_features,11)
    return model
def train_fasterrcnn(data_root="data/bdd100k_yolo",epochs=20,batch_size=4,device="cuda"):
    dev=torch.device(device if device=="cpu" or torch.cuda.is_available() else "cpu")
    ds=BDDYoloDataset(data_root,"train")
    dl=DataLoader(ds,batch_size=batch_size,shuffle=True,num_workers=4,
                  collate_fn=collate_fn,pin_memory=dev.type=="cuda")
    model=build_model().to(dev)
    opt=torch.optim.SGD([p for p in model.parameters() if p.requires_grad],
                        lr=.005,momentum=.9,weight_decay=.0005)
    sched=torch.optim.lr_scheduler.StepLR(opt,step_size=max(1,epochs//3),gamma=.1)
    Path("checkpoints").mkdir(exist_ok=True); history=[]
    for ep in range(epochs):
        model.train(); loss_sum=0; n=0
        for images,targets in dl:
            images=[x.to(dev) for x in images]
            targets=[{k:v.to(dev) for k,v in t.items()} for t in targets]
            losses=model(images,targets); loss=sum(losses.values())
            opt.zero_grad(); loss.backward(); torch.nn.utils.clip_grad_norm_(model.parameters(),10)
            opt.step(); loss_sum+=float(loss.detach()); n+=1
        sched.step(); row={"epoch":ep+1,"loss":loss_sum/max(1,n)}
        history.append(row); print(row,flush=True)
        torch.save({"model":model.state_dict(),"epoch":ep+1},
                   f"checkpoints/fasterrcnn_epoch_{ep+1:03d}.pth")
    torch.save({"model":model.state_dict()},"checkpoints/fasterrcnn_bdd100k.pth")
    Path("outputs").mkdir(exist_ok=True)
    Path("outputs/fasterrcnn_train.json").write_text(json.dumps(history,indent=2))
    return model
def evaluate_fasterrcnn(data_root,checkpoint,split="benchmark",device="cuda",score_threshold=.001):
    dev=torch.device(device if device=="cpu" or torch.cuda.is_available() else "cpu")
    ds=BDDYoloDataset(data_root,split)
    dl=DataLoader(ds,batch_size=2,shuffle=False,num_workers=2,collate_fn=collate_fn)
    model=build_model(pretrained=False)
    state=torch.load(checkpoint,map_location="cpu",weights_only=False)
    model.load_state_dict(state["model"]); model.to(dev).eval()
    images=[]; anns=[]; preds=[]; ann_id=1; image_id=1
    with torch.inference_mode():
        for ims,targets in dl:
            outs=model([im.to(dev) for im in ims])
            for im,t,pred in zip(ims,targets,outs):
                _,h,w=im.shape
                images.append({"id":image_id,"width":w,"height":h,"file_name":ds.images[image_id-1].name})
                for b,c in zip(t["boxes"].tolist(),t["labels"].tolist()):
                    x1,y1,x2,y2=b
                    anns.append({"id":ann_id,"image_id":image_id,"category_id":int(c),
                        "bbox":[x1,y1,x2-x1,y2-y1],"area":(x2-x1)*(y2-y1),"iscrowd":0})
                    ann_id+=1
                for b,c,s in zip(pred["boxes"].cpu().tolist(),pred["labels"].cpu().tolist(),pred["scores"].cpu().tolist()):
                    if s<score_threshold: continue
                    x1,y1,x2,y2=b
                    preds.append({"image_id":image_id,"category_id":int(c),
                                  "bbox":[x1,y1,x2-x1,y2-y1],"score":float(s)})
                image_id+=1
    if not anns: raise RuntimeError("No ground-truth annotations found; cannot calculate AP.")
    coco=COCO(); coco.dataset={"images":images,"annotations":anns,
        "categories":[{"id":i+1,"name":f"class_{i}"} for i in range(10)]}
    coco.createIndex()
    Path("outputs").mkdir(exist_ok=True)
    pred_path=Path("outputs/fasterrcnn_predictions.json"); pred_path.write_text(json.dumps(preds))
    dt=coco.loadRes(str(pred_path))
    ev=COCOeval(coco,dt,"bbox"); ev.evaluate(); ev.accumulate(); ev.summarize()
    result={"map50_95":float(ev.stats[0]),"map50":float(ev.stats[1]),
            "images":len(images),"ground_truth_boxes":len(anns),"predictions":len(preds)}
    Path("outputs/fasterrcnn_eval.json").write_text(json.dumps(result,indent=2))
    return result
