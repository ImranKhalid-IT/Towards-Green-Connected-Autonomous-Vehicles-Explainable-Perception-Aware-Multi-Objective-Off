"""Write environment provenance for reproducible cloud-GPU experiments."""
import json, platform, subprocess, sys
from pathlib import Path
def collect():
    out={"python":sys.version,"platform":platform.platform(),"processor":platform.processor()}
    try:
        import torch
        out.update({"torch":torch.__version__,"cuda_available":torch.cuda.is_available(),
                    "cuda_version":torch.version.cuda,
                    "gpu":torch.cuda.get_device_name(0) if torch.cuda.is_available() else None})
    except Exception as e: out["torch_error"]=str(e)
    try:
        import ultralytics
        out["ultralytics"]=ultralytics.__version__
    except Exception: pass
    try:
        out["nvidia_smi"]=subprocess.check_output(["nvidia-smi"],text=True,timeout=10)
    except Exception: out["nvidia_smi"]="unavailable"
    return out
if __name__=="__main__":
    Path("outputs").mkdir(exist_ok=True)
    Path("outputs/environment.json").write_text(json.dumps(collect(),indent=2))
    print(json.dumps(collect(),indent=2))
