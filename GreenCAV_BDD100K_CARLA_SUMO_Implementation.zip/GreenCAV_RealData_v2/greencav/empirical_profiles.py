"""Build detector profiles from measured evaluation/profile JSONs for PPO integration.

Energy must be measured on the target vehicle/edge hardware. If absent, this
module leaves energy_j as null; it never fabricates energy from mAP or latency.
"""
import json, glob
from pathlib import Path
def build(eval_dir="outputs", profile_dir="outputs", output="outputs/empirical_detector_profiles.json"):
    evals={}
    for f in glob.glob(str(Path(eval_dir)/"eval_*.json")):
        d=json.loads(Path(f).read_text())
        name=Path(d.get("weights","")).parent.parent.name or Path(f).stem.replace("eval_","")
        evals[name]=d
    profiles={}
    for f in glob.glob(str(Path(profile_dir)/"profile_*.json")):
        d=json.loads(Path(f).read_text())
        name=Path(d["weights"]).stem
        profiles[name]={"map50":None,"map50_95":None,
            "latency_mean_ms":d.get("mean_ms"),"latency_p95_ms":d.get("p95_ms"),
            "energy_j":None,"energy_status":"not measured on target vehicle/edge hardware",
            "source_profile":f}
    for name,d in evals.items():
        profiles.setdefault(name,{})
        profiles[name].update({"map50":d.get("map50"),"map50_95":d.get("map50_95"),
                                "precision":d.get("precision"),"recall":d.get("recall")})
    Path(output).parent.mkdir(parents=True,exist_ok=True)
    Path(output).write_text(json.dumps(profiles,indent=2))
    return profiles
if __name__=="__main__": print(json.dumps(build(),indent=2))
