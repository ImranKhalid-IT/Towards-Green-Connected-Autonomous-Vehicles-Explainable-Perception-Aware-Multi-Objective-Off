"""BDD100K Detection 2020 Scalabel JSON -> YOLO dataset.

Important split policy:
- Official BDD100K train is split deterministically into train + val_internal.
- Official labelled BDD100K val is copied to benchmark and never used for tuning.
- The unlabelled official test images are not used for mAP.
"""
from pathlib import Path
from collections import Counter
import json, random, shutil
from PIL import Image
from .classes import CATEGORY_TO_ID

def _normalise_category(value):
    return str(value or "").strip().lower().replace("-", " ").replace("_", " ")

def _convert_records(records, image_dir, out_root, split):
    image_out = out_root / "images" / split
    label_out = out_root / "labels" / split
    image_out.mkdir(parents=True, exist_ok=True)
    label_out.mkdir(parents=True, exist_ok=True)
    counts, missing, written = Counter(), 0, 0
    for rec in records:
        name = rec.get("name")
        if not name:
            continue
        source = image_dir / name
        if not source.exists():
            missing += 1
            continue
        dest = image_out / name
        if not dest.exists():
            try:
                dest.symlink_to(source.resolve())
            except OSError:
                shutil.copy2(source, dest)
        with Image.open(source) as im:
            width, height = im.size
        rows = []
        for item in rec.get("labels", []):
            cat = _normalise_category(item.get("category"))
            # normalized category key with spaces, then explicit mapping
            class_id = CATEGORY_TO_ID.get(cat)
            if class_id is None or "box2d" not in item:
                continue
            b = item["box2d"]
            x1, y1, x2, y2 = [float(b[k]) for k in ("x1","y1","x2","y2")]
            x1, x2 = max(0,min(x1,width)), max(0,min(x2,width))
            y1, y2 = max(0,min(y1,height)), max(0,min(y2,height))
            bw, bh = x2-x1, y2-y1
            if bw < 2 or bh < 2:
                continue
            xc, yc = ((x1+x2)/2)/width, ((y1+y2)/2)/height
            rows.append(f"{class_id} {xc:.7f} {yc:.7f} {bw/width:.7f} {bh/height:.7f}")
            counts[class_id] += 1
        (label_out/(Path(name).stem+".txt")).write_text("\n".join(rows)+("\n" if rows else ""))
        written += 1
    return {"split":split,"images":written,"missing_images":missing,
            "instances_by_class_id":dict(counts)}

def convert_bdd100k(data_root="data/bdd100k", out_root="data/bdd100k_yolo",
                    internal_val_fraction=0.10, seed=42):
    data_root, out_root = Path(data_root), Path(out_root)
    train_json = data_root/"labels"/"bdd100k_labels_images_train.json"
    val_json = data_root/"labels"/"bdd100k_labels_images_val.json"
    train_images = data_root/"images"/"100k"/"train"
    val_images = data_root/"images"/"100k"/"val"
    for p in (train_json,val_json,train_images,val_images):
        if not p.exists(): raise FileNotFoundError(p)
    train_records = json.loads(train_json.read_text())
    rng = random.Random(seed)
    indices = list(range(len(train_records))); rng.shuffle(indices)
    n_val = max(1, int(len(indices)*internal_val_fraction))
    val_ids = set(indices[:n_val])
    train_part = [r for i,r in enumerate(train_records) if i not in val_ids]
    internal_val = [r for i,r in enumerate(train_records) if i in val_ids]
    official_val = json.loads(val_json.read_text())
    reports = [
        _convert_records(train_part,train_images,out_root,"train"),
        _convert_records(internal_val,train_images,out_root,"val_internal"),
        _convert_records(official_val,val_images,out_root,"benchmark"),
    ]
    manifest = {"seed":seed,"internal_val_fraction":internal_val_fraction,
                "official_train_records":len(train_records),
                "train_records":len(train_part),"internal_val_records":len(internal_val),
                "official_validation_records":len(official_val),
                "reports":reports}
    out_root.mkdir(parents=True,exist_ok=True)
    (out_root/"split_manifest.json").write_text(json.dumps(manifest,indent=2))
    return manifest

if __name__ == "__main__":
    print(json.dumps(convert_bdd100k(),indent=2))
