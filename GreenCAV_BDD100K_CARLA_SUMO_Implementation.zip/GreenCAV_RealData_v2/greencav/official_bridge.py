"""Launch CARLA 0.9.15's official SUMO integration script.

Use the bridge shipped with the exact CARLA 0.9.15 distribution. This wrapper
does not implement actor synchronization itself; it delegates to the official
run_synchronization.py script to avoid a misleading pseudo-synchronized run.
"""
import argparse, subprocess, sys
from pathlib import Path
def main():
    p=argparse.ArgumentParser()
    p.add_argument("--bridge-script",required=True,help="Path to CARLA PythonAPI/examples/sumo_integration/run_synchronization.py")
    p.add_argument("--bridge-args",default="",help="Arguments passed unchanged to the official bridge")
    a=p.parse_args()
    script=Path(a.bridge_script)
    if not script.exists(): raise FileNotFoundError(script)
    cmd=[sys.executable,str(script),*a.bridge_args.split()]
    print("Launching official bridge:", " ".join(cmd),flush=True)
    raise SystemExit(subprocess.call(cmd))
if __name__=="__main__": main()
