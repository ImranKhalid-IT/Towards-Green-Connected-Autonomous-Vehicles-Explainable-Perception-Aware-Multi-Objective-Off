"""YOLOv8s/YOLOv8m training. YOLOv5s is handled by the official YOLOv5 repo."""
from ultralytics import YOLO
from pathlib import Path

MODEL_WEIGHTS = {"yolov8s":"yolov8s.pt", "yolov8m":"yolov8m.pt"}

def train_yolo(model_name, data_yaml="configs/bdd100k_train.yaml", epochs=100,
               imgsz=640, batch=16, device="0", workers=8, seed=42):
    if model_name not in MODEL_WEIGHTS:
        raise ValueError("This module trains yolov8s/yolov8m. Use scripts/train_yolov5s.sh for exact YOLOv5s.")
    model = YOLO(MODEL_WEIGHTS[model_name])
    return model.train(data=data_yaml, epochs=epochs, imgsz=imgsz, batch=batch,
        device=device, workers=workers, seed=seed, deterministic=True,
        patience=30, cos_lr=True, amp=True, project="runs/bdd100k",
        name=model_name, pretrained=True, cache=False)

def evaluate_yolo(weights, data_yaml="configs/bdd100k_benchmark.yaml",
                  imgsz=640, device="0", split="val"):
    model=YOLO(weights)
    metrics=model.val(data=data_yaml, split=split, imgsz=imgsz, device=device,
                      plots=True, save_json=True, verbose=True)
    return {"weights":str(weights),"split":split,"map50":float(metrics.box.map50),
            "map50_95":float(metrics.box.map),"precision":float(metrics.box.mp),
            "recall":float(metrics.box.mr)}
