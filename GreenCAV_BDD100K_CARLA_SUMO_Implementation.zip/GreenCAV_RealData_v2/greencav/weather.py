"""Export labelled BDD100K validation image manifests by official weather metadata."""
from collections import defaultdict
from pathlib import Path
import json
def export_weather_manifests(label_json,image_dir,out_dir="outputs/weather"):
    records=json.loads(Path(label_json).read_text()); groups=defaultdict(list)
    for rec in records:
        attrs=rec.get("attributes") or {}
        weather=str(attrs.get("weather") or "unknown").lower().replace(" ","_")
        groups[weather].append(str(Path(image_dir)/rec["name"]))
    out=Path(out_dir); out.mkdir(parents=True,exist_ok=True)
    report={}
    for weather,paths in groups.items():
        (out/f"{weather}.txt").write_text("\n".join(paths)+"\n")
        report[weather]=len(paths)
    (out/"counts.json").write_text(json.dumps(report,indent=2))
    return report
