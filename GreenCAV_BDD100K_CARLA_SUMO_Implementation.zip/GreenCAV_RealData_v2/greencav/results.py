"""Create one CSV from recorded detector evaluations and latency profiles."""
import glob,json,csv
from pathlib import Path
def merge(folder="outputs",output="outputs/detector_results.csv"):
    rows=[]
    for pat in ("eval_*.json","profile_*.json","fasterrcnn_eval.json"):
        for f in glob.glob(str(Path(folder)/pat)):
            d=json.loads(Path(f).read_text()); d["file"]=f; rows.append(d)
    if not rows: raise RuntimeError("No evaluation/profile result files found.")
    keys=sorted({k for r in rows for k in r})
    Path(output).parent.mkdir(parents=True,exist_ok=True)
    with open(output,"w",newline="") as fp:
        w=csv.DictWriter(fp,fieldnames=keys); w.writeheader(); w.writerows(rows)
    return output
