from greencav.classes import CATEGORY_TO_ID, BDD_CLASSES
def test_categories():
    assert len(BDD_CLASSES)==10
    assert CATEGORY_TO_ID["traffic light"]==8
    assert CATEGORY_TO_ID["traffic sign"]==9
