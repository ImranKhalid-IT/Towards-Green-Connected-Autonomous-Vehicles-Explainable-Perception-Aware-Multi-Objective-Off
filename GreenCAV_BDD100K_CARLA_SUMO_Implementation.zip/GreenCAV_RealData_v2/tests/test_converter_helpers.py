from greencav.bdd_converter import _normalise_category
def test_category_normalisation():
    assert _normalise_category("traffic_light")=="traffic light"
    assert _normalise_category("traffic light")=="traffic light"
