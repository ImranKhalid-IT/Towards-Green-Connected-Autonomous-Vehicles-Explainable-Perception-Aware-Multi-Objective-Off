#!/usr/bin/env python3
"""Fast PIL + FFmpeg animated visualisation of the paper's CAV offloading workflow.

This is an explanatory animation based on manuscript settings and reported
aggregate results. It is not a live CARLA/SUMO recording and does not load
the trained PPO weights.
"""
import math, subprocess, shutil
import numpy as np
from PIL import Image, ImageDraw, ImageFont

W,H,FPS,DURATION = 1280,720,15,20
NFRAMES = FPS*DURATION
OUT = "cav_offloading_simulation.mp4"
PREVIEW = "cav_offloading_simulation_preview.png"
SEED = 20261101
rng = np.random.default_rng(SEED)

C = {
 "navy":"#102C43","ink":"#18364B","muted":"#61798A","blue":"#168BD2",
 "blue2":"#53BCEB","cyan":"#20BDD0","teal":"#159B91","green":"#31A66B",
 "orange":"#F28C28","red":"#D85C58","purple":"#7867C5","sky":"#DDF2FC",
 "sky2":"#A9DDF3","road":"#3A4C59","white":"#FFFFFF","panel":"#F4F8FB",
 "line":"#D9E5EC","pale_blue":"#E9F5FB","pale_green":"#EAF7EF",
 "pale_orange":"#FFF3E6","pale_purple":"#F1EEFC","pale_red":"#FCEDEC",
 "yellow":"#F4C64E"
}
font_dir="/usr/share/fonts/truetype/dejavu"
def font(sz,bold=False):
    f=f"{font_dir}/DejaVuSans{'-Bold' if bold else ''}.ttf"
    try: return ImageFont.truetype(f,sz)
    except: return ImageFont.load_default()

F={s:font(s) for s in [10,11,12,13,14,15,16,17,18,19,20,22,24]}
FB={s:font(s,True) for s in [10,11,12,13,14,15,16,17,18,19,20,22,24]}

def text(d,xy,s,size=12,color=None,bold=False,anchor=None):
    d.text(xy,str(s),font=(FB if bold else F).get(size,font(size,bold)),
           fill=color or C["ink"],anchor=anchor)

def roundbox(d,box,fill,outline=None,width=1,r=10):
    d.rounded_rectangle(box,radius=r,fill=fill,outline=outline,width=width)

def line(d,pts,fill,width=2):
    d.line(pts,fill=fill,width=width,joint="curve")

def arrow(d,p1,p2,color,width=3,head=10):
    d.line([p1,p2],fill=color,width=width)
    a=math.atan2(p2[1]-p1[1],p2[0]-p1[0])
    left=(p2[0]-head*math.cos(a-.55),p2[1]-head*math.sin(a-.55))
    right=(p2[0]-head*math.cos(a+.55),p2[1]-head*math.sin(a+.55))
    d.polygon([p2,left,right],fill=color)

def bezier(p0,p1,p2,p3,u):
    v=1-u
    return (v**3*p0[0]+3*v*v*u*p1[0]+3*v*u*u*p2[0]+u**3*p3[0],
            v**3*p0[1]+3*v*v*u*p1[1]+3*v*u*u*p2[1]+u**3*p3[1])

def dashed(d,p1,p2,fill,width=2,dash=9,gap=7):
    x1,y1=p1; x2,y2=p2
    dx=x2-x1; dy=y2-y1; L=max(1,math.hypot(dx,dy))
    ux,uy=dx/L,dy/L
    pos=0
    while pos<L:
        end=min(pos+dash,L)
        d.line([(x1+ux*pos,y1+uy*pos),(x1+ux*end,y1+uy*end)],
               fill=fill,width=width)
        pos=end+gap

def draw_car(d,x,y,color,roof,label,scale=1.0,box=True):
    w=108*scale; h=31*scale
    d.ellipse((x+12*scale,y+24*scale,x+42*scale,y+54*scale),
              fill="#243744",outline="#152B38",width=1)
    d.ellipse((x+72*scale,y+24*scale,x+102*scale,y+54*scale),
              fill="#243744",outline="#152B38",width=1)
    d.ellipse((x+21*scale,y+33*scale,x+33*scale,y+45*scale),fill="#B9C8D0")
    d.ellipse((x+81*scale,y+33*scale,x+93*scale,y+45*scale),fill="#B9C8D0")
    d.rounded_rectangle((x,y,x+w,y+h+22*scale),radius=int(9*scale),
                        fill=color,outline="#405C6D",width=2)
    d.polygon([(x+20*scale,y+6*scale),(x+39*scale,y-13*scale),
               (x+78*scale,y-13*scale),(x+93*scale,y+6*scale)],
              fill=roof,outline="#405C6D")
    d.polygon([(x+43*scale,y-9*scale),(x+57*scale,y-9*scale),
               (x+57*scale,y+5*scale),(x+31*scale,y+5*scale)],
              fill="#7BB9D4")
    d.polygon([(x+62*scale,y-9*scale),(x+76*scale,y-9*scale),
               (x+88*scale,y+5*scale),(x+62*scale,y+5*scale)],
              fill="#7BB9D4")
    d.ellipse((x+w-5*scale,y+11*scale,x+w+1*scale,y+17*scale),fill="#FFE28B")
    if label:
        text(d,(x+w/2,y-27*scale),label,10,C["navy"],True,anchor="mm")
    if box:
        dashed(d,(x-5,y-19*scale),(x+w+5,y-19*scale),C["cyan"],1,5,4)
        dashed(d,(x-5,y-19*scale),(x-5,y+h+29*scale),C["cyan"],1,5,4)
        dashed(d,(x+w+5,y-19*scale),(x+w+5,y+h+29*scale),C["cyan"],1,5,4)
        dashed(d,(x-5,y+h+29*scale),(x+w+5,y+h+29*scale),C["cyan"],1,5,4)

def draw_rsu(d):
    x=785; base=315; top=165
    line(d,[(x,base),(x-30,top)],"#5B7382",4)
    line(d,[(x,base),(x+30,top)],"#5B7382",4)
    line(d,[(x-30,top),(x+30,top)],"#5B7382",3)
    for f in [.25,.5,.75]:
        yy=base-f*(base-top); dx=30*(1-f)
        line(d,[(x-dx,yy-10),(x+dx,yy+10)],"#8BA0AC",2)
        line(d,[(x-dx,yy+10),(x+dx,yy-10)],"#8BA0AC",1)
    line(d,[(x,top-3),(x,top-28)],"#526C7B",3)
    for dx in [-16,0,16]:
        roundbox(d,(x+dx-4,top-23,x+dx+4,top+7),"#E8F1F5","#5A7686",1,3)
        line(d,[(x+dx,top-18),(x+dx,top+2)],C["blue"],2)
    for r in [13,22,31]:
        d.arc((x-r,top-59-r*.5,x+r,top-59+r*.5),195,345,fill=C["blue"],width=2)
    text(d,(x,124),"RSU / C-V2X",10,C["navy"],True,anchor="mm")
    text(d,(x,141),"5.9 GHz • 10 MHz",8,C["muted"],anchor="mm")

def draw_mec(d,pulse=0):
    x,y=875,225
    roundbox(d,(x,y,x+105,y+92),"#E8F0F5","#718998",2,9)
    d.polygon([(x-3,y),(x+52,y-17),(x+108,y)],fill="#D2E0E8",outline="#718998")
    for j in range(2):
        sx=x+12+j*49
        roundbox(d,(sx,y+12,sx+40,y+81),"#263F53","#173247",1,4)
        for k in range(3):
            yy=y+18+k*19
            roundbox(d,(sx+5,yy,sx+35,yy+12),"#41657D","#7893A3",1,2)
            d.ellipse((sx+8,yy+4,sx+13,yy+9),fill="#55D4BD")
            d.ellipse((sx+17,yy+4,sx+22,yy+9),fill="#55D4BD")
    if pulse:
        d.ellipse((x+39,y-27,x+67,y+1),outline=C["cyan"],width=3)
    text(d,(x+52,y-27),"MEC SERVER",10,C["navy"],True,anchor="mm")
    text(d,(x+52,y-11),"Xeon CPU + RTX 3090-class",7,C["muted"],anchor="mm")

def draw_static():
    im=Image.new("RGB",(W,H),C["panel"])
    d=ImageDraw.Draw(im)
    # sky
    for yy in range(90,315):
        q=(yy-90)/225
        col=(int(221-50*q),int(242-20*q),int(252-5*q))
        d.line([(0,yy),(W,yy)],fill=col)
    # header
    roundbox(d,(18,12,1262,82),"#FFFFFF","#DCE7ED",1,12)
    text(d,(38,37),"EXPLAINABLE PERCEPTION-AWARE OFFLOADING FOR CONNECTED AUTONOMOUS VEHICLES",
         19,C["navy"],True)
    text(d,(39,62),"C-V2X V2I  •  Preference-conditioned PPO  •  RSU-assisted MEC  •  Uncertainty-gated dual-head XAI",
         10,C["muted"])
    roundbox(d,(1040,24,1238,62),C["pale_blue"],"#C6E2F0",1,8)
    text(d,(1139,43),"10 Hz  |  100 ms DEADLINE",10,C["blue"],True,anchor="mm")

    # skyline
    brng=np.random.default_rng(22)
    x=0
    while x<990:
        bw=int(brng.integers(28,62)); bh=int(brng.integers(65,170))
        col=brng.choice(["#B6CBD7","#8EAAB9","#D2E0E7"])
        d.rectangle((x,310-bh,x+bw,310),fill=col,outline="#9EB4C0",width=1)
        for wy in range(310-bh+10,304,18):
            for wx in range(x+5,x+bw-4,12):
                d.rectangle((wx,wy,wx+4,wy+6),fill="#EDF7FB")
        x+=bw+int(brng.integers(6,15))
    # clouds
    for cx,cy in [(145,130),(405,120),(725,150),(930,115)]:
        for ox,oy,r in [(-18,3,18),(0,-8,24),(24,4,18),(9,11,18)]:
            d.ellipse((cx+ox-r,cy+oy-r,cx+ox+r,cy+oy+r),
                      fill="#F6FCFF")
    # tree belt
    d.rectangle((0,310,990,326),fill="#A2C991")
    for tx in range(10,990,48):
        line(d,[(tx,308),(tx,329)],"#785E45",3)
        d.ellipse((tx-12,294,tx+12,318),fill="#62A77D")
        d.ellipse((tx-7,288,tx+15,312),fill="#3D8A65")
    # road
    d.rectangle((0,326,990,452),fill=C["road"])
    d.line([(0,331),(990,331)],fill="#EAF0F3",width=3)
    d.line([(0,449),(990,449)],fill="#EAF0F3",width=3)
    for yy in [368,410]:
        for xx in range(0,990,84):
            d.line([(xx,yy),(xx+48,yy)],fill="#F6F6EF",width=3)
    # crosswalk
    for xx in range(710,790,13):
        d.rectangle((xx,329,xx+7,354),fill="#F4F6F4")
    # local chip callout
    roundbox(d,(22,222,225,286),"#FFFFFF","#BFDCEB",1,9)
    roundbox(d,(34,238,66,270),C["pale_blue"],"#B9DDED",1,5)
    text(d,(50,254),"CPU",10,C["blue"],True,anchor="mm")
    text(d,(77,247),"ON-VEHICLE JETSON",9,C["navy"],True)
    text(d,(77,265),"1.8 GHz effective",9,C["muted"])
    # weather share panel
    roundbox(d,(22,105,360,184),"#FFFFFF","#D9E6ED",1,9)
    text(d,(37,123),"WEATHER MIX IN THE WORKLOAD",10,C["navy"],True)
    text(d,(37,146),"CLEAR 87%   •   LIGHT RAIN 8%",9,C["muted"])
    text(d,(37,166),"HEAVY RAIN 3%   •   DENSE SMOG 2%",9,C["muted"])
    # xai inset
    roundbox(d,(392,105,705,220),"#FFFFFF","#BFDCEB",1,10)
    text(d,(408,124),"UNCERTAINTY-GATED DUAL-HEAD XAI",10,C["navy"],True)
    # small camera view with heatmap
    roundbox(d,(408,140,507,203),"#253D4D","#597687",1,5)
    d.polygon([(415,196),(460,196),(496,146),(455,146)],fill="#435C6C")
    d.ellipse((453,157,488,191),fill="#E96D51")
    d.ellipse((443,164,477,194),fill="#F6C04B")
    d.rectangle((450,161,488,193),outline="#6FE0C5",width=2)
    text(d,(520,154),"Saliency head",9,C["orange"],True)
    text(d,(520,174),"Object alignment",9,C["teal"],True)
    text(d,(520,194),"Fused reliability feedback",8,C["ink"])
    # RSU and MEC
    draw_rsu(d)
    draw_mec(d)
    # label on road camera
    d.rectangle((74,310,80,326),fill="#607B89")
    roundbox(d,(62,291,95,313),"#E8F0F4","#607B89",1,4)
    d.ellipse((83,297,92,306),fill=C["blue"])
    text(d,(105,301),"Roadside camera",8,C["navy"],True)
    # traffic light
    roundbox(d,(825,286,844,329),"#263C4A","#162A36",1,4)
    for i,col in enumerate(["#E75B55","#E8B64A","#43B77A"]):
        d.ellipse((831,291+i*12,839,299+i*12),fill=col)
    # right telemetry panel
    roundbox(d,(1004,100,1260,452),"#FFFFFF","#D8E5EC",1,12)
    text(d,(1022,123),"LIVE SYSTEM TELEMETRY",12,C["navy"],True)
    text(d,(1022,143),"Task-by-task process view",9,C["muted"])
    roundbox(d,(1020,158,1244,187),C["pale_blue"],None,0,7)
    # link + weather dynamic
    text(d,(1031,173),"LINK STATUS",8,C["blue"],True)
    text(d,(1232,173),"GOOD • 30 Mbps",8,C["blue"],True,anchor="ra")
    roundbox(d,(1020,196,1244,225),"#F3F6F8",None,0,7)
    text(d,(1031,211),"POLICY ACTION",8,C["muted"],True)
    text(d,(1232,211),"MEC + YOLOv8s",8,C["ink"],True,anchor="ra")
    text(d,(1022,246),"CURRENT TASK LATENCY / 100 ms",8,C["muted"],True)
    roundbox(d,(1022,257,1242,267),"#E6EDF1",None,0,4)
    # dynamic bar placeholder
    roundbox(d,(1022,257,1130,267),C["green"],None,0,4)
    text(d,(1239,278),"49.3 / 100 ms",8,C["green"],True,anchor="ra")
    # metric tiles
    tiles=[(1020,294,"MEAN LATENCY","49.3 ms",C["blue"]),
           (1134,294,"ENERGY / TASK","1.30 J",C["teal"]),
           (1020,355,"mAP@0.5","83.1%",C["purple"]),
           (1134,355,"DEADLINE VIOL.","0.6%",C["green"])]
    for x,y,title,val,col in tiles:
        roundbox(d,(x,y,x+106,y+50),"#F7FAFC","#E4EDF2",1,7)
        text(d,(x+8,y+13),title,7,C["muted"],True)
        text(d,(x+8,y+36),val,14,col,True)
    # bottom workflow cards
    titles=[
      ("01","SENSE","Camera frame • 10 Hz","Objects + uncertainty",C["blue"],C["pale_blue"]),
      ("02","PPO DECISION","Joint action (oᵢ, mᵢ)","Site + detector",C["purple"],C["pale_purple"]),
      ("03","EXECUTE","25 kB latent feature","Local Jetson / MEC",C["teal"],C["pale_green"]),
      ("04","XAI GATE","u_pred ≥ τ ?","25% explain • 75% bypass",C["orange"],C["pale_orange"]),
      ("05","FEEDBACK","Reliability to next state","Latency • energy • accuracy",C["green"],C["pale_green"]),
    ]
    x0=22; y0=475; cw=235; ch=95; gap=13
    for i,(num,title,l1,l2,accent,tint) in enumerate(titles):
        x=x0+i*(cw+gap)
        roundbox(d,(x,y0,x+cw,y0+ch),"#FFFFFF","#D8E5EC",1,9)
        d.rounded_rectangle((x,y0,x+cw,y0+6),radius=4,fill=accent)
        roundbox(d,(x+10,y0+17,x+42,y0+43),tint,None,0,5)
        text(d,(x+26,y0+30),num,9,accent,True,anchor="mm")
        text(d,(x+51,y0+30),title,10,C["navy"],True)
        text(d,(x+13,y0+61),l1,9,C["ink"])
        text(d,(x+13,y0+80),l2,8,C["muted"])
        if i<4:
            arrow(d,(x+cw+1,y0+50),(x+cw+gap-2,y0+50),C["muted"],2,7)
    # KPI strip
    roundbox(d,(22,584,1258,688),"#FFFFFF","#D8E5EC",1,10)
    text(d,(39,601),"REPORTED MEAN PERFORMANCE  |  30,000 TASKS / RUN  •  30 PAIRED RUNS",
         9,C["navy"],True)
    kpis=[
      ("49.3 ms","Mean latency",C["blue"]),
      ("1.30 J","Energy / task",C["teal"]),
      ("83.1%","mAP@0.5",C["purple"]),
      ("0.6%","Deadline violations",C["green"]),
      ("78.1%","Offloaded tasks",C["orange"]),
    ]
    for i,(val,desc,col) in enumerate(kpis):
        x=52+i*245
        if i: d.line((x-18,615,x-18,675),fill="#E5EDF2",width=1)
        text(d,(x+92,662),desc,8,C["muted"],anchor="mm")
        roundbox(d,(x+10,675,x+174,680),"#E8EEF2",None,0,2)
        roundbox(d,(x+10,675,x+10,680),col,None,0,2)
    text(d,(640,704),
         "EXPLANATORY ANIMATION USING MANUSCRIPT SETTINGS + REPORTED MEANS — NOT A LIVE CARLA/SUMO CAPTURE",
         7,C["muted"],anchor="mm")
    return im

# Generate task states using the paper's reported link-state and weather shares.
n_tasks=int(DURATION*10)+2
task_states=[]
for i in range(n_tasks):
    li=int(rng.choice(3,p=[.05,.35,.60]))
    wi=int(rng.choice(4,p=[.87,.08,.03,.02]))
    off=bool(rng.random()<[.320,.680,.878][li])
    unc=float(rng.random())
    xai=unc>=.75
    q=int(rng.integers(2,22))
    dets=["YOLOv5s","YOLOv8s","YOLOv8m","Faster R-CNN"]
    if wi==0: det=dets[int(rng.choice([0,1,2],p=[.55,.35,.10]))]
    elif wi==1: det=dets[int(rng.choice([1,2,3],p=[.45,.40,.15]))]
    else: det=dets[int(rng.choice([2,3],p=[.35,.65]))]
    lat=float(np.clip(rng.normal(49.3,8),25,94))
    task_states.append((li,wi,off,unc,xai,q,det,lat))

def draw_frame(static,t,frame):
    im=static.copy()
    d=ImageDraw.Draw(im)
    # car movement; one CAV and three traffic vehicles
    cavx=105+(t*43)%555
    car_positions=[
      (cavx,355,"#137DBB","#82C9E8","CAV-01",1.0),
      ((320+t*27)%900,408,"#F0F3F5","#D2E0E7","",.82),
      ((630+t*19)%900,355,"#E8B84B","#F4D786","",.82),
      ((880-t*24)%900,408,"#D85C58","#F1A29D","",.82),
    ]
    for x,y,col,roof,lab,sc in car_positions:
        draw_car(d,x,y,col,roof,lab,sc,box=True)
    # moving task and link states at 10 Hz
    task=int(t*10)
    li,wi,off,unc,xai,q,det,lat=task_states[min(task,len(task_states)-1)]
    rates=[5,15,30]; linknames=["POOR","MEDIUM","GOOD"]
    weather=["CLEAR","LIGHT RAIN","HEAVY RAIN","DENSE SMOG"]
    linkcol=[C["red"],C["orange"],C["green"]][li]
    wcol=[C["green"],C["blue"],C["orange"],C["red"]][wi]
    # dynamic status panel
    d.rounded_rectangle((1020,158,1244,187),radius=7,fill=C["pale_blue"])
    text(d,(1031,173),f"LINK: {linknames[li]} • {rates[li]} Mbps",8,linkcol,True,anchor="lm")
    text(d,(1232,173),weather[wi],7,wcol,True,anchor="rm")
    d.rounded_rectangle((1020,196,1244,225),radius=7,fill="#F3F6F8")
    site="MEC" if off else "LOCAL"
    text(d,(1031,211),f"ACTION: {site} + {det}",8,C["ink"],True,anchor="lm")
    # latency meter
    d.rounded_rectangle((1022,257,1242,267),radius=4,fill="#E6EDF1")
    bw=int(220*min(lat/100,1))
    d.rounded_rectangle((1022,257,1022+bw,267),radius=4,
                        fill=C["green"] if lat<=100 else C["red"])
    d.rectangle((1022,257,1242,267),outline="#D6E1E7",width=1)
    d.rectangle((1022+220,253,1024+220,271),fill=C["red"])
    d.rectangle((1022,257,1022+bw,267),fill=C["green"])
    # dynamic offload / XAI indicator
    text(d,(1022,426),f"OFFLOAD {78.1:.1f}%  •  XAI {25:.0f}%",8,C["orange"],True)
    text(d,(1022,440),"vs DRL: −16.0% latency  •  −14.3% energy",7,C["muted"],True)
    # task status over road

    # communication paths and animated packets
    sx=cavx+86; sy=343
    rsu=(785,165); mec=(875,225)
    if off:
        p0=(sx,sy); p1=(sx+70,230); p2=(720,190); p3=rsu
        # faint dashed uplink
        points=[bezier(p0,p1,p2,p3,u) for u in np.linspace(0,1,34)]
        for j in range(0,len(points)-1,2):
            line(d,[points[j],points[j+1]],C["blue"],2)
        # packets travel vehicle -> RSU
        for k in range(3):
            u=(t*1.1+k*.31)%1
            px,py=bezier(p0,p1,p2,p3,u)
            d.ellipse((px-5,py-5,px+5,py+5),fill=C["blue"],outline="white",width=1)
        # RSU -> MEC backhaul
        dashed(d,(814,163),(875,225),C["purple"],2,7,5)
        for k in range(2):
            u=(t*.8+k*.48)%1
            px=814+(875-814)*u; py=163+(225-163)*u
            d.ellipse((px-4,py-4,px+4,py+4),fill=C["purple"],outline="white")
        # return results MEC -> vehicle
        q0=(875,244); q1=(820,290); q2=(sx+60,250); q3=(sx,sy)
        for k in range(2):
            u=(t*.82+k*.48)%1
            px,py=bezier(q0,q1,q2,q3,u)
            d.ellipse((px-4,py-4,px+4,py+4),fill=C["green"],outline="white")
        text(d,(560,263),"25 kB latent feature uplink",8,C["blue"],True)
        text(d,(790,287),"detections returned",8,C["green"],True)
        text(d,(670,210),"V2I",8,C["blue"],True)
    else:
        # local task path to the Jetson bubble
        d.line([(sx,sy),(230,260)],fill=C["purple"],width=2)
        for k in range(2):
            u=(t*1.4+k*.5)%1
            px=sx+(230-sx)*u; py=sy+(260-sy)*u
            d.ellipse((px-4,py-4,px+4,py+4),fill=C["purple"],outline="white")
        text(d,(300,275),"Local inference on Jetson",8,C["purple"],True)

    # pulse on MEC while it is processing an offloaded task
    if off:
        pulse=2+int(2*(1+math.sin(t*5)))
        d.ellipse((918-pulse,204-pulse,918+pulse,204+pulse),
                  outline=C["cyan"],width=2)

    # XAI gate: highlight heatmap inset when triggered
    if xai:
        d.rounded_rectangle((392,105,705,220),radius=10,
                            outline=C["orange"],width=3)
        d.ellipse((682,112,699,129),fill=C["orange"],outline="white",width=1)
        text(d,(690,120),"!",9,"white",True,anchor="mm")
        roundbox(d,(612,109,695,132),C["pale_orange"],C["orange"],1,6)
        text(d,(653,120),"TRIGGER",8,C["orange"],True,anchor="mm")
    else:
        d.rounded_rectangle((392,105,705,220),radius=10,
                            outline="#BFDCEB",width=1)
        roundbox(d,(612,109,695,132),"#F3F6F8","#D7E1E7",1,6)
        text(d,(653,120),"BYPASS",8,C["muted"],True,anchor="mm")

    # highlight workflow card according to stage in 5-step cycle
    stage=int((t%7.5)/1.5)
    x0=22; y0=475; cw=235; gap=13
    accents=[C["blue"],C["purple"],C["teal"],C["orange"],C["green"]]
    for i in range(5):
        x=x0+i*(cw+gap)
        if i==stage:
            d.rounded_rectangle((x,y0,x+cw,y0+95),radius=9,
                                outline=accents[i],width=3)
            d.ellipse((x+cw-24,y0+69,x+cw-10,y0+83),fill=accents[i])
        else:
            d.rounded_rectangle((x,y0,x+cw,y0+95),radius=9,
                                outline="#D8E5EC",width=1)

    # KPI numbers count up to the reported aggregate results.
    ease=min(t/6.0,1)
    ease=1-(1-ease)**3
    kpi_values=[(49.3,"{:.1f} ms",100),(1.30,"{:.2f} J",2),
                (83.1,"{:.1f}%",100),(0.6,"{:.1f}%",5),(78.1,"{:.1f}%",100)]
    for i,(target,fmt,maxv) in enumerate(kpi_values):
        x=52+i*245
        val=target*ease
        text(d,(x+92,636),fmt.format(val),17,
             [C["blue"],C["teal"],C["purple"],C["green"],C["orange"]][i],
             True,anchor="mm")
        d.rounded_rectangle((x+10,675,x+174,680),radius=2,fill="#E8EEF2")
        d.rounded_rectangle((x+10,675,x+10+int(164*min(val/maxv,1)),680),
                            radius=2,fill=[C["blue"],C["teal"],C["purple"],C["green"],C["orange"]][i])
    # top-right small sequence clock and task counter
    text(d,(1018,66),f"TASK {task+1:04d}  •  SIM {t:04.1f}s",8,C["muted"],True,anchor="ra")
    return im

def main():
    if not shutil.which("ffmpeg"):
        raise RuntimeError("ffmpeg not found. Install ffmpeg and retry.")
    static=draw_static()
    # Save poster frame with initial moving elements.
    first=draw_frame(static,10.0,int(10.0*FPS))
    first.save(PREVIEW)
    cmd=[
      "ffmpeg","-y","-loglevel","error",
      "-f","rawvideo","-pix_fmt","rgb24","-s",f"{W}x{H}",
      "-r",str(FPS),"-i","-",
      "-an","-c:v","libx264","-preset","ultrafast","-crf","23",
      "-pix_fmt","yuv420p","-movflags","+faststart",OUT
    ]
    proc=subprocess.Popen(cmd,stdin=subprocess.PIPE)
    try:
        for i in range(NFRAMES):
            t=i/FPS
            frame=draw_frame(static,t,i)
            proc.stdin.write(frame.tobytes())
        proc.stdin.close()
        code=proc.wait()
        if code!=0:
            raise RuntimeError(f"ffmpeg exited with code {code}")
    finally:
        if proc.poll() is None:
            proc.kill()
    print(f"Created {OUT}: {DURATION}s, {FPS} FPS, {W}x{H}")
    print(f"Created {PREVIEW}")
    print("Visualisation only: uses manuscript parameters and aggregate means; not a live CARLA/SUMO capture.")

if __name__=="__main__":
    main()
